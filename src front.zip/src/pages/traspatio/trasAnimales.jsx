import { useEffect, useMemo, useState } from 'react';
import { AlertCircle, Filter, Search, RefreshCw } from 'lucide-react';
import { getAnimalesPanelTraspatio, getAnimalesCrudTraspatio } from '../../services/apiTraspatio/animalesPanel.js';

const statusLabel = (estado) => {
  const normalized = String(estado ?? '').trim().toLowerCase();

  if (normalized.includes('certific')) {
    return { label: estado || 'Certificado', className: 'bg-[#EAF3E6] text-[#5C743D]' };
  }

  if (normalized.includes('revision') || normalized.includes('revisión') || normalized.includes('pendiente')) {
    return { label: estado || 'En revisión', className: 'bg-[#FFF4E5] text-[#D97706]' };
  }

  return { label: estado || 'Sin estado', className: 'bg-gray-100 text-gray-700' };
};

const formatDate = (value) => {
  if (!value) return 'N/D';

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value);

  return new Intl.DateTimeFormat('es-MX', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  }).format(date).replace('.', '');
};

const formatWeight = (value) => {
  if (value === null || value === undefined || value === '') return 'N/D';
  return `${value} kg`;
};

const formatAge = (value) => {
  if (value === null || value === undefined || value === '') return 'N/D';
  return `${value} años`;
};

const formatPrice = (value) => {
  if (value === null || value === undefined || value === '') return 'N/D';

  const numericValue = typeof value === 'number' ? value : Number(value);
  if (Number.isNaN(numericValue)) return String(value);

  return new Intl.NumberFormat('es-MX', {
    style: 'currency',
    currency: 'MXN',
    maximumFractionDigits: 2,
  }).format(numericValue);
};

// Normalización flexible para soportar los campos tanto del Panel como del CRUD
const normalizeAnimal = (animal) => {
  const source = animal ?? {};

  return {
    id: source.id_animal ?? source.arete_id ?? source.id ?? 'Sin ID',
    tipo: source.tipo_animal ?? source.tipo ?? source.categoria ?? 'Sin tipo',
    raza: source.raza ?? source.nombre_raza ?? 'Sin raza',
    edadAnios: source.edad_anios ?? source.edad,
    pesoKg: source.peso_kg ?? source.peso,
    estado: source.estado_certificacion ?? source.estado ?? 'Sin estado',
    precioEstimado: source.precio_estimado ?? source.precio,
    fechaRegistro: source.fecha_registro ?? source.fecha_creacion ?? source.created_at,
  };
};

const sortByFechaRegistroDesc = (animales) => {
  return [...animales].sort((left, right) => {
    const leftTime = new Date(left.fechaRegistro ?? 0).getTime();
    const rightTime = new Date(right.fechaRegistro ?? 0).getTime();
    return rightTime - leftTime;
  });
};

export default function TrasAnimales() {
  const [animales, setAnimales] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('Todos');
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState('');
  const [dataSource, setDataSource] = useState('panel');

  const extractErrorMessage = (err) => {
    if (err?.response?.data) {
      const data = err.response.data;
      if (typeof data.detail === 'string') return data.detail;
      if (Array.isArray(data.detail)) {
        return data.detail.map((e) => `${e.loc?.join('.')}: ${e.msg}`).join(' | ');
      }
      if (data.mensaje) return data.mensaje;
    }
    return err?.message || 'Error de conexión con el servidor.';
  };

  const loadAnimales = async (showRefreshingState = false) => {
    if (showRefreshingState) {
      setIsRefreshing(true);
    } else {
      setIsLoading(true);
    }

    setError('');

    try {
      // Intento 1: Cargar desde el Panel de traspatio
      const response = await getAnimalesPanelTraspatio();
      const rawData = Array.isArray(response) ? response : response?.animales ?? [];
      setAnimales(sortByFechaRegistroDesc(rawData.map(normalizeAnimal)));
      setDataSource('panel');
      return;
    } catch (panelErr) {
      console.warn('Fallo al obtener animales del Panel de traspatio:', panelErr);
      const panelErrorMsg = extractErrorMessage(panelErr);

      try {
        // Intento 2: Fallback al CRUD de traspatio
        const responseCrud = await getAnimalesCrudTraspatio({ skip: 0, limit: 100 });
        const rawCrudData = Array.isArray(responseCrud) ? responseCrud : [];
        setAnimales(sortByFechaRegistroDesc(rawCrudData.map(normalizeAnimal)));
        setDataSource('crud');
        return;
      } catch (crudErr) {
        console.error('Fallo al obtener animales del CRUD de traspatio:', crudErr);
        const crudErrorMsg = extractErrorMessage(crudErr);
        setError(`Panel API: [${panelErrorMsg}] | CRUD API: [${crudErrorMsg}]`);
        setAnimales([]);
      }
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    const timeoutId = window.setTimeout(() => {
      void loadAnimales();
    }, 0);

    return () => window.clearTimeout(timeoutId);
  }, []);

  const statusSummary = useMemo(() => {
    return animales.reduce(
      (accumulator, animal) => {
        const normalizedStatus = String(animal.estado ?? '').trim().toLowerCase();
        accumulator.total += 1;

        if (normalizedStatus.includes('certific')) {
          accumulator.certificados += 1;
        } else if (normalizedStatus.includes('revision') || normalizedStatus.includes('revisión')) {
          accumulator.enRevision += 1;
        } else if (normalizedStatus.includes('pendiente')) {
          accumulator.pendientes += 1;
        }

        return accumulator;
      },
      { total: 0, certificados: 0, enRevision: 0, pendientes: 0 }
    );
  }, [animales]);

  const statusOptions = useMemo(() => {
    const uniqueStatuses = new Set(animales.map((animal) => animal.estado).filter(Boolean));
    return ['Todos', ...Array.from(uniqueStatuses)];
  }, [animales]);

  const filteredAnimales = useMemo(() => {
    const normalizedQuery = searchQuery.trim().toLowerCase();
    return animales.filter((animal) => {
      const matchesQuery =
        !normalizedQuery ||
        `${animal.id} ${animal.tipo} ${animal.raza} ${animal.estado}`.toLowerCase().includes(normalizedQuery);
      const matchesStatus = statusFilter === 'Todos' || animal.estado === statusFilter;
      return matchesQuery && matchesStatus;
    });
  }, [animales, searchQuery, statusFilter]);

  const resetFilters = () => {
    setSearchQuery('');
    setStatusFilter('Todos');
  };

  return (
    <div className="mx-auto max-w-6xl space-y-6 pb-10 font-serif">
      <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-[#3B2211]">Mis Animales</h1>
          <p className="mt-2 font-sans text-gray-500">
            Consulta los animales registrados en tu traspatio directamente desde la base de datos.
          </p>
        </div>
        <div className="rounded-xl border border-[#E8ECE1] bg-white px-4 py-3 font-sans text-sm text-gray-600 shadow-sm">
          <span className="font-semibold text-[#3B2211]">Origen de datos: </span>
          {dataSource === 'panel' ? 'Panel de traspatio' : 'CRUD de traspatio'}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 font-sans md:grid-cols-4">
        <div className="rounded-xl border border-gray-200 bg-white p-4 text-center shadow-sm">
          <p className="mb-1 text-xs text-gray-500">Total registrados</p>
          <p className="text-2xl font-bold text-[#3B2211]">{statusSummary.total}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4 text-center shadow-sm">
          <p className="mb-1 text-xs text-gray-500">Certificados</p>
          <p className="text-2xl font-bold text-[#5C743D]">{statusSummary.certificados}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4 text-center shadow-sm">
          <p className="mb-1 text-xs text-gray-500">En revisión</p>
          <p className="text-2xl font-bold text-[#D97706]">{statusSummary.enRevision}</p>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4 text-center shadow-sm">
          <p className="mb-1 text-xs text-gray-500">Pendientes</p>
          <p className="text-2xl font-bold text-[#7A8A61]">{statusSummary.pendientes}</p>
        </div>
      </div>

      <div className="flex flex-col gap-4 rounded-xl border border-gray-200 bg-white p-4 shadow-sm md:flex-row md:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(event) => setSearchQuery(event.target.value)}
            placeholder="Buscar por ID, tipo, raza o estado..."
            className="w-full rounded-lg border border-gray-200 py-2.5 pl-10 pr-4 text-sm outline-none focus:ring-2 focus:ring-[#5C743D]"
          />
        </div>

        <select
          value={statusFilter}
          onChange={(event) => setStatusFilter(event.target.value)}
          className="cursor-pointer rounded-lg border border-gray-200 bg-white px-4 py-2.5 text-sm text-gray-700 outline-none focus:ring-2 focus:ring-[#5C743D] md:w-56"
        >
          {statusOptions.map((option) => (
            <option key={option} value={option}>
              {option}
            </option>
          ))}
        </select>

        <button
          onClick={resetFilters}
          className="inline-flex items-center justify-center gap-2 rounded-lg border border-gray-300 bg-white px-5 py-2.5 text-sm font-semibold text-gray-700 transition-colors hover:bg-gray-50"
        >
          <Filter className="h-4 w-4" />
          Limpiar
        </button>

        <button
          onClick={() => loadAnimales(true)}
          disabled={isLoading || isRefreshing}
          className="inline-flex items-center justify-center gap-2 rounded-lg bg-[#3B2211] px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition-colors hover:bg-[#2A180C] disabled:cursor-not-allowed disabled:opacity-70"
        >
          <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          {isRefreshing ? 'Actualizando' : 'Actualizar'}
        </button>
      </div>

      {error ? (
        <div className="flex flex-col gap-2 rounded-xl border border-red-200 bg-red-50 p-4 font-sans text-sm text-red-700">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 font-bold">
              <AlertCircle className="h-5 w-5 shrink-0" />
              <span>Detalle de error devuelto por la API:</span>
            </div>
            <button
              onClick={() => loadAnimales()}
              className="font-semibold text-red-700 underline decoration-red-300 underline-offset-2 hover:text-red-900"
            >
              Reintentar
            </button>
          </div>
          <p className="rounded border border-red-100 bg-white p-2 font-mono text-xs text-red-800 break-words">
            {error}
          </p>
        </div>
      ) : null}

      <div className="overflow-hidden rounded-2xl border border-gray-200 bg-[#FDFDFB] shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left font-sans text-sm text-gray-800">
            <thead className="border-b border-[#E8ECE1] bg-[#F7F8F3] text-xs font-bold uppercase tracking-wide text-[#3B2211]">
              <tr>
                <th className="px-6 py-5">ID</th>
                <th className="px-6 py-5">Tipo</th>
                <th className="px-6 py-5">Raza</th>
                <th className="px-6 py-5">Edad</th>
                <th className="px-6 py-5">Peso (kg)</th>
                <th className="px-6 py-5">Estado</th>
                <th className="px-6 py-5">Precio Est.</th>
                <th className="px-6 py-5">Fecha Registro</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E8ECE1]">
              {isLoading ? (
                <tr>
                  <td colSpan="8" className="px-6 py-12 text-center text-gray-500">
                    Cargando animales desde el backend...
                  </td>
                </tr>
              ) : filteredAnimales.length === 0 ? (
                <tr>
                  <td colSpan="8" className="px-6 py-12 text-center text-gray-500">
                    No hay animales que coincidan con los filtros actuales.
                  </td>
                </tr>
              ) : (
                filteredAnimales.map((animal) => {
                  const badge = statusLabel(animal.estado);

                  return (
                    <tr key={`${animal.id}-${animal.fechaRegistro ?? ''}`} className="transition-colors hover:bg-white">
                      <td className="px-6 py-4 font-bold text-[#3B2211]">{animal.id}</td>
                      <td className="px-6 py-4">{animal.tipo}</td>
                      <td className="px-6 py-4">{animal.raza}</td>
                      <td className="px-6 py-4">{formatAge(animal.edadAnios)}</td>
                      <td className="px-6 py-4">{formatWeight(animal.pesoKg)}</td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex rounded-full px-3 py-1 text-xs font-bold ${badge.className}`}>
                          {badge.label}
                        </span>
                      </td>
                      <td className="px-6 py-4 font-semibold">{formatPrice(animal.precioEstimado)}</td>
                      <td className="px-6 py-4 text-gray-500">{formatDate(animal.fechaRegistro)}</td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}