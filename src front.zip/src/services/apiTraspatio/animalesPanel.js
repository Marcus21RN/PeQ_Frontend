import api from '../api.js';

export const getAnimalesPanelTraspatio = async () => {
	const response = await api.get('/traspatio/panel/animales/');
	return response.data;
};


export const getAnimalesCrudTraspatio = async (params = {}) => {
  const response = await api.get('/traspatio/animales-crud/', {
    params,
  });
  return response.data;
};